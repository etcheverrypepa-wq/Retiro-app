import { useState, useMemo } from "react";

const ALL_DATA = [{"id":"ID-1","nombre":"Otero","apellido":"Emi","dni":"","celular":"","email":"","area":"Caminar","grupo":"1","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-2","nombre":"Tommei","apellido":"Juana","dni":"","celular":"","email":"","area":"Caminar","grupo":"1","rol":"coordinador","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":10000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-3","nombre":"Bellezze","apellido":"Juan Ignacio","dni":"49438321","celular":"","email":"","area":"Caminar","grupo":"1","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-4","nombre":"sala","apellido":"valentina","dni":"49398847","celular":"","email":"","area":"Caminar","grupo":"1","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-5","nombre":"Bressano","apellido":"Mora","dni":"49439043","celular":"","email":"","area":"Caminar","grupo":"1","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-6","nombre":"Lynch","apellido":"Bautista Tomas","dni":"48858721","celular":"","email":"","area":"Caminar","grupo":"1","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-7","nombre":"Orti Muro","apellido":"Camila","dni":"50204120","celular":"","email":"","area":"Caminar","grupo":"1","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-8","nombre":"Tonnelier","apellido":"Camila","dni":"48871270","celular":"","email":"","area":"Caminar","grupo":"1","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-9","nombre":"Alvarez cabal","apellido":"Bautista","dni":"48313665","celular":"","email":"","area":"Caminar","grupo":"1","rol":"participante","estado":"Debe efectivo","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":10000,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-10","nombre":"Scavino","apellido":"Lorenzo","dni":"48447937","celular":"","email":"","area":"Caminar","grupo":"1","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-11","nombre":"Feldtmann","apellido":"Mateo","dni":"49064471","celular":"","email":"","area":"Caminar","grupo":"1","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-12","nombre":"Cappelletti","apellido":"Santiago","dni":"49120055","celular":"","email":"","area":"Caminar","grupo":"1","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-13","nombre":"parada","apellido":"sofia","dni":"49257891","celular":"","email":"","area":"Caminar","grupo":"1","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-14","nombre":"","apellido":"Gabo","dni":"","celular":"","email":"","area":"Caminar","grupo":"2","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-15","nombre":"","apellido":"Cande","dni":"","celular":"","email":"","area":"Caminar","grupo":"2","rol":"coordinador","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":4,"entradas_efectivo":0,"entradas_transferencia":40000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-16","nombre":"","apellido":"Pili","dni":"","celular":"","email":"","area":"Caminar","grupo":"2","rol":"coordinador","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":50000,"entradas_transferencia":0,"entro_plata":"Sí","observaciones":"","asistencia":false},{"id":"ID-17","nombre":"Saravia","apellido":"Joaquin","dni":"48936303","celular":"","email":"","area":"Caminar","grupo":"2","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-18","nombre":"isella cordini","apellido":"franca","dni":"49091763","celular":"","email":"","area":"Caminar","grupo":"2","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-19","nombre":"castellano","apellido":"sofia maria","dni":"49358451","celular":"","email":"","area":"Caminar","grupo":"2","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-20","nombre":"Alvarez Fierro","apellido":"Santiago","dni":"49121501","celular":"","email":"","area":"Caminar","grupo":"2","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-21","nombre":"Zimmermann","apellido":"Rafael","dni":"49004302","celular":"","email":"","area":"Caminar","grupo":"2","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-22","nombre":"piñeiro","apellido":"milagros","dni":"48111996","celular":"","email":"","area":"Caminar","grupo":"2","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-23","nombre":"Salinas","apellido":"Benjamin","dni":"49317223","celular":"","email":"","area":"Caminar","grupo":"2","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":8,"entradas_efectivo":0,"entradas_transferencia":80000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-24","nombre":"Lynch","apellido":"Antonio Maria","dni":"48803359","celular":"","email":"","area":"Caminar","grupo":"2","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":7,"entradas_efectivo":0,"entradas_transferencia":70000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-25","nombre":"falvo","apellido":"mia","dni":"48447950","celular":"","email":"","area":"Caminar","grupo":"2","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-26","nombre":"Gorostidi","apellido":"Fermin","dni":"48936371","celular":"","email":"","area":"Caminar","grupo":"2","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-27","nombre":"Gall Kindsvater","apellido":"Uma","dni":"49548593","celular":"","email":"","area":"Caminar","grupo":"2","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-28","nombre":"Alabedra","apellido":"Delfina","dni":"49192335","celular":"","email":"","area":"Caminar","grupo":"2","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-29","nombre":"DI PAOLO","apellido":"PEDRO TOMAS","dni":"48860961","celular":"","email":"","area":"Caminar","grupo":"2","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-30","nombre":"lunkes","apellido":"leonardo","dni":"96167777","celular":"","email":"","area":"Caminar","grupo":"2","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-31","nombre":"","apellido":"Ine","dni":"","celular":"","email":"","area":"Caminar","grupo":"3","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-32","nombre":"","apellido":"Lucas","dni":"","celular":"","email":"","area":"Caminar","grupo":"3","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-33","nombre":"","apellido":"Guada","dni":"","celular":"","email":"","area":"Caminar","grupo":"3","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-34","nombre":"Vulijscher","apellido":"Alejo","dni":"49375556","celular":"","email":"","area":"Caminar","grupo":"3","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-35","nombre":"Berardi","apellido":"Mateo","dni":"49193673","celular":"","email":"","area":"Caminar","grupo":"3","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-36","nombre":"de la torre","apellido":"milagros","dni":"49379389","celular":"","email":"","area":"Caminar","grupo":"3","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":7,"entradas_efectivo":0,"entradas_transferencia":70000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-37","nombre":"Montero","apellido":"Benjamin","dni":"49520221","celular":"","email":"","area":"Caminar","grupo":"3","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":10000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-38","nombre":"Ravera Pieroni","apellido":"Bianca","dni":"51702228","celular":"","email":"","area":"Caminar","grupo":"3","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":2,"entradas_efectivo":0,"entradas_transferencia":20000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-39","nombre":"Orellana Vitucci","apellido":"Fabrizio","dni":"48999143","celular":"","email":"","area":"Caminar","grupo":"3","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-40","nombre":"Sanchez De la Roza","apellido":"Melina","dni":"49600557","celular":"","email":"","area":"Caminar","grupo":"3","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-41","nombre":"Fernandez Grau","apellido":"Felipe Lucas","dni":"49377884","celular":"","email":"","area":"Caminar","grupo":"3","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-42","nombre":"Grehan Elfersy","apellido":"Francisco","dni":"48975214","celular":"","email":"","area":"Caminar","grupo":"3","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":10000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-43","nombre":"Coppolillo","apellido":"Juan Ignacio","dni":"48857344","celular":"","email":"","area":"Caminar","grupo":"3","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":0,"entradas_transferencia":50000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-44","nombre":"Pie Martin","apellido":"Malena","dni":"48861201","celular":"","email":"","area":"Caminar","grupo":"3","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-45","nombre":"Carullo","apellido":"Siena","dni":"49156174","celular":"","email":"","area":"Caminar","grupo":"3","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-46","nombre":"Rizzi","apellido":"Bautista","dni":"48870791","celular":"","email":"","area":"Caminar","grupo":"3","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-47","nombre":"","apellido":"Mari","dni":"","celular":"","email":"","area":"Caminar","grupo":"4","rol":"coordinador","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":8,"entradas_efectivo":0,"entradas_transferencia":80000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-48","nombre":"","apellido":"Euge","dni":"","celular":"","email":"","area":"Caminar","grupo":"4","rol":"coordinador","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":0,"entradas_transferencia":50000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-49","nombre":"Otero","apellido":"Felix","dni":"48860989","celular":"","email":"","area":"Caminar","grupo":"4","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":2,"entradas_efectivo":0,"entradas_transferencia":20000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-50","nombre":"Grillo","apellido":"Marco","dni":"48802156","celular":"","email":"","area":"Caminar","grupo":"4","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":4,"entradas_efectivo":0,"entradas_transferencia":40000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-51","nombre":"Calvo","apellido":"Pedro Francisco","dni":"49248114","celular":"","email":"","area":"Caminar","grupo":"4","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-52","nombre":"De Filippo","apellido":"Trinidad","dni":"49317249","celular":"","email":"","area":"Caminar","grupo":"4","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-53","nombre":"Gómez cuervo","apellido":"Facunndo","dni":"49064263","celular":"","email":"","area":"Caminar","grupo":"4","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":3,"entradas_efectivo":0,"entradas_transferencia":30000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-54","nombre":"Martinez Casas","apellido":"Ildiko","dni":"48389983","celular":"","email":"","area":"Caminar","grupo":"4","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-55","nombre":"Ravettini","apellido":"Santino","dni":"48242098","celular":"","email":"","area":"Caminar","grupo":"4","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-56","nombre":"Ledesma","apellido":"Gabriel","dni":"49248165","celular":"","email":"","area":"Caminar","grupo":"4","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-57","nombre":"Rubio","apellido":"Nicolas","dni":"48858887","celular":"","email":"","area":"Caminar","grupo":"4","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-58","nombre":"Ricotti","apellido":"Milagros","dni":"48999290","celular":"","email":"","area":"Caminar","grupo":"4","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-59","nombre":"Anadon","apellido":"Carmela","dni":"49121721","celular":"","email":"","area":"Caminar","grupo":"4","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-60","nombre":"","apellido":"Salva","dni":"","celular":"","email":"","area":"Caminar","grupo":"5","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-61","nombre":"","apellido":"Pachi","dni":"","celular":"","email":"","area":"Caminar","grupo":"5","rol":"coordinador","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":4,"entradas_efectivo":0,"entradas_transferencia":40000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-62","nombre":"","apellido":"Lupi","dni":"","celular":"","email":"","area":"Caminar","grupo":"5","rol":"coordinador","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":10000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-63","nombre":"Caprarelli","apellido":"Veronica paula","dni":"49375569","celular":"","email":"","area":"Caminar","grupo":"5","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":10000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-64","nombre":"Iriondo","apellido":"Abril","dni":"48861236","celular":"","email":"","area":"Caminar","grupo":"5","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":10000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-65","nombre":"De Los Santos","apellido":"Isabella","dni":"48857200","celular":"","email":"","area":"Caminar","grupo":"5","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":3,"entradas_efectivo":0,"entradas_transferencia":30000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-66","nombre":"Dardanelli","apellido":"Felipe","dni":"49519041","celular":"","email":"","area":"Caminar","grupo":"5","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":10,"entradas_efectivo":0,"entradas_transferencia":100000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-67","nombre":"Beilis","apellido":"Catalina","dni":"49006616","celular":"","email":"","area":"Caminar","grupo":"5","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-68","nombre":"Sanzetenea Morales","apellido":"Amira","dni":"49551734","celular":"","email":"","area":"Caminar","grupo":"5","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-69","nombre":"Mackinlay","apellido":"Belén maría","dni":"49192363","celular":"","email":"","area":"Caminar","grupo":"5","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-70","nombre":"Priotto","apellido":"Candela","dni":"48591244","celular":"","email":"","area":"Caminar","grupo":"5","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":0,"entradas_transferencia":50000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-71","nombre":"Ferreyro","apellido":"Fausto","dni":"49374776","celular":"","email":"","area":"Caminar","grupo":"5","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-72","nombre":"","apellido":"Agus","dni":"","celular":"","email":"","area":"Caminar","grupo":"6","rol":"coordinador","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":10000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-73","nombre":"","apellido":"Juana","dni":"","celular":"","email":"","area":"Caminar","grupo":"6","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-74","nombre":"balada","apellido":"sophia","dni":"48522014","celular":"","email":"","area":"Caminar","grupo":"6","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-75","nombre":"Murdoch","apellido":"Kenneth","dni":"49248101","celular":"","email":"","area":"Caminar","grupo":"6","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-76","nombre":"Moreno","apellido":"Macarena Valentina","dni":"48368482","celular":"","email":"","area":"Caminar","grupo":"6","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-77","nombre":"Hansen","apellido":"Serena","dni":"48458859","celular":"","email":"","area":"Caminar","grupo":"6","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-78","nombre":"Cabona","apellido":"Chiara","dni":"49094352","celular":"","email":"","area":"Caminar","grupo":"6","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-79","nombre":"De la vega","apellido":"Matias Jorge","dni":"49317543","celular":"","email":"","area":"Caminar","grupo":"6","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-80","nombre":"Russell","apellido":"Emma","dni":"49552427","celular":"","email":"","area":"Caminar","grupo":"6","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-81","nombre":"Müller","apellido":"Pedro Francisco","dni":"48521842","celular":"","email":"","area":"Caminar","grupo":"6","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-82","nombre":"Maino","apellido":"Morena","dni":"48800694","celular":"","email":"","area":"Caminar","grupo":"6","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-83","nombre":"Correa","apellido":"Lautaro Felipe","dni":"48447902","celular":"","email":"","area":"Caminar","grupo":"6","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-84","nombre":"","apellido":"Popi","dni":"","celular":"","email":"","area":"Caminar","grupo":"7","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-85","nombre":"","apellido":"Caste","dni":"","celular":"","email":"","area":"Caminar","grupo":"7","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-86","nombre":"","apellido":"Lape","dni":"","celular":"","email":"","area":"Caminar","grupo":"7","rol":"coordinador","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":7,"entradas_efectivo":0,"entradas_transferencia":70000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-87","nombre":"Mazzoleni","apellido":"Delfina","dni":"48870738","celular":"","email":"","area":"Caminar","grupo":"7","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-88","nombre":"Areco","apellido":"Siena Esperanza","dni":"48857085","celular":"","email":"","area":"Caminar","grupo":"7","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-89","nombre":"Galansky","apellido":"María","dni":"49064406","celular":"","email":"","area":"Caminar","grupo":"7","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-90","nombre":"Narvaez","apellido":"Juan Ignacio","dni":"50563195","celular":"","email":"","area":"Caminar","grupo":"7","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-91","nombre":"Esquivel","apellido":"Patricio","dni":"48855064","celular":"","email":"","area":"Caminar","grupo":"7","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":3,"entradas_efectivo":0,"entradas_transferencia":30000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-92","nombre":"Montero Andújar","apellido":"Sofía","dni":"48214805","celular":"","email":"","area":"Caminar","grupo":"7","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-93","nombre":"Ongania","apellido":"Pedro","dni":"49248072","celular":"","email":"","area":"Caminar","grupo":"7","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-94","nombre":"Muñoz","apellido":"Elena","dni":"49358379","celular":"","email":"","area":"Caminar","grupo":"7","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-95","nombre":"Diaco","apellido":"Camila","dni":"41358437","celular":"","email":"","area":"Caminar","grupo":"7","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-96","nombre":"Alvarez Carpi","apellido":"Camila","dni":"49123928","celular":"","email":"","area":"Caminar","grupo":"7","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-97","nombre":"Lavayen","apellido":"Olivia","dni":"48860487","celular":"","email":"","area":"Caminar","grupo":"7","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-98","nombre":"","apellido":"Toto","dni":"","celular":"","email":"","area":"Caminar","grupo":"8","rol":"coordinador","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":2,"entradas_efectivo":0,"entradas_transferencia":20000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-99","nombre":"","apellido":"Benja","dni":"","celular":"","email":"","area":"Caminar","grupo":"8","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-100","nombre":"Agnoletti Cosentino","apellido":"Lucia","dni":"48936109","celular":"","email":"","area":"Caminar","grupo":"8","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-101","nombre":"Dates","apellido":"Simon Luis","dni":"49090860","celular":"","email":"","area":"Caminar","grupo":"8","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-102","nombre":"morixe","apellido":"juana","dni":"48803166","celular":"","email":"","area":"Caminar","grupo":"8","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-103","nombre":"Castro huebner","apellido":"Lola","dni":"49156398","celular":"","email":"","area":"Caminar","grupo":"8","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-104","nombre":"Pereyra Spinelli","apellido":"Tomas","dni":"48576989","celular":"","email":"","area":"Caminar","grupo":"8","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-105","nombre":"Gomez Lugani","apellido":"Josefina","dni":"49086937","celular":"","email":"","area":"Caminar","grupo":"8","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-106","nombre":"Borghello Del Barco","apellido":"Jano","dni":"48999315","celular":"","email":"","area":"Caminar","grupo":"8","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-107","nombre":"Fabra Spinosa","apellido":"Martina Giuliana","dni":"49160205","celular":"","email":"","area":"Caminar","grupo":"8","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-108","nombre":"hoevel","apellido":"ines","dni":"49550601","celular":"","email":"","area":"Caminar","grupo":"8","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":7,"entradas_efectivo":0,"entradas_transferencia":70000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-109","nombre":"Scurci","apellido":"Rocio","dni":"49092340","celular":"","email":"","area":"Caminar","grupo":"8","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-110","nombre":"Changala","apellido":"Jacinta","dni":"49094279","celular":"","email":"","area":"Caminar","grupo":"8","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-111","nombre":"Perez Olivieri","apellido":"Michella Florencia","dni":"94792275","celular":"","email":"","area":"Caminar","grupo":"8","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-112","nombre":"lascano","apellido":"felix","dni":"49433741","celular":"","email":"","area":"Caminar","grupo":"8","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-113","nombre":"","apellido":"Belu","dni":"","celular":"","email":"","area":"Caminar","grupo":"9","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-114","nombre":"","apellido":"Manu","dni":"","celular":"","email":"","area":"Caminar","grupo":"9","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-115","nombre":"","apellido":"Nacho","dni":"","celular":"","email":"","area":"Caminar","grupo":"9","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-116","nombre":"Liparoti","apellido":"Juana","dni":"48591496","celular":"","email":"","area":"Caminar","grupo":"9","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-117","nombre":"Castro","apellido":"Bautista","dni":"48034066","celular":"","email":"","area":"Caminar","grupo":"9","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-118","nombre":"MILANESI CASTIGLIA","apellido":"SOFIA","dni":"49009405","celular":"","email":"","area":"Caminar","grupo":"9","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":13,"entradas_efectivo":0,"entradas_transferencia":130000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-119","nombre":"martínez casas pagani","apellido":"victoria","dni":"50084598","celular":"","email":"","area":"Caminar","grupo":"9","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-120","nombre":"Del Gesso","apellido":"Juan Martin","dni":"48178719","celular":"","email":"","area":"Caminar","grupo":"9","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-121","nombre":"Franchino","apellido":"María Guadalupe","dni":"49248012","celular":"","email":"","area":"Caminar","grupo":"9","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-122","nombre":"Moglio Perrone","apellido":"Ines Maria","dni":"48858633","celular":"","email":"","area":"Caminar","grupo":"9","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-123","nombre":"Kawakami","apellido":"Olivia","dni":"49064212","celular":"","email":"","area":"Caminar","grupo":"9","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-124","nombre":"Ianni Muller","apellido":"Martina","dni":"49192456","celular":"","email":"","area":"Caminar","grupo":"9","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":10000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-125","nombre":"Soler Campero","apellido":"Juana","dni":"49241879","celular":"","email":"","area":"Caminar","grupo":"9","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-126","nombre":"Poodts","apellido":"Esmeralda","dni":"49377836","celular":"","email":"","area":"Caminar","grupo":"9","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-127","nombre":"Kloury","apellido":"Lucas","dni":"48936247","celular":"","email":"","area":"Caminar","grupo":"9","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-128","nombre":"","apellido":"Tina","dni":"","celular":"","email":"","area":"Caminar","grupo":"10","rol":"coordinador","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":4,"entradas_efectivo":0,"entradas_transferencia":40000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-129","nombre":"","apellido":"Cata","dni":"","celular":"","email":"","area":"Caminar","grupo":"10","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-130","nombre":"","apellido":"Cande","dni":"","celular":"","email":"","area":"Caminar","grupo":"10","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-131","nombre":"Rodriguez Modarelli","apellido":"Guadalupe","dni":"48214988","celular":"","email":"","area":"Caminar","grupo":"10","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-132","nombre":"Beccar Varela","apellido":"Sara","dni":"48976709","celular":"","email":"","area":"Caminar","grupo":"10","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-133","nombre":"Ferrari Cuello","apellido":"María Ema","dni":"49248024","celular":"","email":"","area":"Caminar","grupo":"10","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-134","nombre":"Pastoriza","apellido":"Estanislao","dni":"48801886","celular":"","email":"","area":"Caminar","grupo":"10","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-135","nombre":"Kronberg","apellido":"Camila","dni":"49519398","celular":"","email":"","area":"Caminar","grupo":"10","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-136","nombre":"Yasnig","apellido":"Agustin tomas","dni":"48578128","celular":"","email":"","area":"Caminar","grupo":"10","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-137","nombre":"Commenge","apellido":"Sofia","dni":"49374876","celular":"","email":"","area":"Caminar","grupo":"10","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-138","nombre":"farias","apellido":"emilia","dni":"49518645","celular":"","email":"","area":"Caminar","grupo":"10","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-139","nombre":"CANO ZANOTTI","apellido":"JULIETA","dni":"49194377","celular":"","email":"","area":"Caminar","grupo":"10","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-140","nombre":"Garcia Rodriguez","apellido":"Julieta","dni":"48674808","celular":"","email":"","area":"Caminar","grupo":"10","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-141","nombre":"Polverigiani","apellido":"Catalina","dni":"48936221","celular":"","email":"","area":"Caminar","grupo":"10","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-142","nombre":"PATRINI SANCHEZ","apellido":"LEONARDO","dni":"51702440","celular":"","email":"","area":"Caminar","grupo":"10","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-143","nombre":"Sanguinetti","apellido":"Azul","dni":"49241815","celular":"","email":"","area":"Caminar","grupo":"10","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-144","nombre":"","apellido":"Cami","dni":"","celular":"","email":"","area":"Caminar","grupo":"11","rol":"coordinador","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":3,"entradas_efectivo":0,"entradas_transferencia":30000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-145","nombre":"","apellido":"Manu","dni":"","celular":"","email":"","area":"Caminar","grupo":"11","rol":"coordinador","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":10000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-146","nombre":"","apellido":"Popa","dni":"","celular":"","email":"","area":"Caminar","grupo":"12","rol":"coordinador","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":12,"entradas_efectivo":0,"entradas_transferencia":120000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-147","nombre":"","apellido":"Yopo","dni":"","celular":"","email":"","area":"Caminar","grupo":"12","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-148","nombre":"Caro","apellido":"Martina Belén","dni":"49358317","celular":"","email":"","area":"Caminar","grupo":"12","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-149","nombre":"Vidal","apellido":"Felipe","dni":"49086885","celular":"","email":"","area":"Caminar","grupo":"12","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-150","nombre":"Sansone","apellido":"Juana","dni":"48178667","celular":"","email":"","area":"Caminar","grupo":"12","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":6,"entradas_efectivo":0,"entradas_transferencia":60000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-151","nombre":"Arata Olmedo","apellido":"Juan Francisco","dni":"48802722","celular":"","email":"","area":"Caminar","grupo":"12","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-152","nombre":"Rettori","apellido":"Santos","dni":"49433533","celular":"","email":"","area":"Caminar","grupo":"12","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-153","nombre":"Pollini Ochoa","apellido":"Margarita","dni":"48111762","celular":"","email":"","area":"Caminar","grupo":"12","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-154","nombre":"Giordano","apellido":"Catalina","dni":"48705286","celular":"","email":"","area":"Caminar","grupo":"12","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-155","nombre":"Grino","apellido":"Maria del Pilar","dni":"48801369","celular":"","email":"","area":"Caminar","grupo":"12","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-156","nombre":"Lauzzana","apellido":"Justina","dni":"48999218","celular":"","email":"","area":"Caminar","grupo":"12","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":7,"entradas_efectivo":0,"entradas_transferencia":70000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-157","nombre":"Mastromonaco","apellido":"Gaspar","dni":"49123612","celular":"","email":"","area":"Caminar","grupo":"12","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-158","nombre":"DE SETA","apellido":"Luciana Priscila","dni":"49194802","celular":"","email":"","area":"Caminar","grupo":"12","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-159","nombre":"Dolinkue blaksley","apellido":"Federico Diego","dni":"48705196","celular":"","email":"","area":"Caminar","grupo":"12","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-160","nombre":"NARDO","apellido":"MARIA DEL ROSARIO","dni":"49313217","celular":"","email":"","area":"Caminar","grupo":"12","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":10000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-161","nombre":"Vernengo Imposti","apellido":"Franco Sebastián","dni":"48243241","celular":"","email":"","area":"Caminar","grupo":"12","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-162","nombre":"","apellido":"Pili","dni":"","celular":"","email":"","area":"Caminar","grupo":"13","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-163","nombre":"","apellido":"Rena","dni":"","celular":"","email":"","area":"Caminar","grupo":"13","rol":"coordinador","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":9,"entradas_efectivo":0,"entradas_transferencia":90000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-164","nombre":"","apellido":"Reni","dni":"","celular":"","email":"","area":"Caminar","grupo":"13","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-165","nombre":"Torrado","apellido":"Camila","dni":"48999352","celular":"","email":"","area":"Caminar","grupo":"13","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":15,"entradas_efectivo":0,"entradas_transferencia":150000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-166","nombre":"Berro Madero","apellido":"Facundo","dni":"49064426","celular":"","email":"","area":"Caminar","grupo":"13","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-167","nombre":"Cañete","apellido":"Federico","dni":"49434161","celular":"","email":"","area":"Caminar","grupo":"13","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-168","nombre":"Cordoba","apellido":"Santiago","dni":"49313291","celular":"","email":"","area":"Caminar","grupo":"13","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-169","nombre":"Moreno","apellido":"Pedro","dni":"49192404","celular":"","email":"","area":"Caminar","grupo":"13","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-170","nombre":"Mazzone Britos","apellido":"Renata Ines","dni":"48987211","celular":"","email":"","area":"Caminar","grupo":"13","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-171","nombre":"Torrella","apellido":"Maria Lujan","dni":"48870751","celular":"","email":"","area":"Caminar","grupo":"13","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-172","nombre":"Bradley","apellido":"Felicitas","dni":"48246290","celular":"","email":"","area":"Caminar","grupo":"13","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-173","nombre":"Torras","apellido":"Juana","dni":"49248109","celular":"","email":"","area":"Caminar","grupo":"13","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-174","nombre":"Erhart del Campo","apellido":"Celina María","dni":"49009201","celular":"","email":"","area":"Caminar","grupo":"13","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":10000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-175","nombre":"mata bustamante","apellido":"sebastian rafael","dni":"48245726","celular":"","email":"","area":"Caminar","grupo":"13","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-176","nombre":"mastroianni","apellido":"dolores","dni":"48561745","celular":"","email":"","area":"Caminar","grupo":"13","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-177","nombre":"Bonfante Grandoli","apellido":"Martin","dni":"49319045","celular":"","email":"","area":"Caminar","grupo":"13","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-178","nombre":"","apellido":"Emi","dni":"","celular":"","email":"","area":"Caminar","grupo":"14","rol":"coordinador","estado":"Debe efectivo","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"Sí","vendio_entradas":"Sí","cantidad_entradas":2,"entradas_efectivo":20000,"entradas_transferencia":60000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-179","nombre":"","apellido":"Chonaz","dni":"","celular":"","email":"","area":"Caminar","grupo":"14","rol":"coordinador","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-180","nombre":"","apellido":"Luzu","dni":"","celular":"","email":"","area":"Caminar","grupo":"14","rol":"coordinador","estado":"Debe efectivo","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":9,"entradas_efectivo":90000,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-181","nombre":"giglio","apellido":"felipe","dni":"48648293","celular":"","email":"","area":"Caminar","grupo":"14","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-182","nombre":"Castiglione","apellido":"Guadalupe","dni":"48936271","celular":"","email":"","area":"Caminar","grupo":"14","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-183","nombre":"Ruiz Murineddu","apellido":"Pilar","dni":"48792967","celular":"","email":"","area":"Caminar","grupo":"14","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-184","nombre":"Bertero","apellido":"Bautista","dni":"49374942","celular":"","email":"","area":"Caminar","grupo":"14","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-185","nombre":"Assisa","apellido":"Maite","dni":"48870681","celular":"","email":"","area":"Caminar","grupo":"14","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-186","nombre":"Fernandez Cisneros","apellido":"Agustina","dni":"49313138","celular":"","email":"","area":"Caminar","grupo":"14","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-187","nombre":"legel","apellido":"catalina","dni":"49255111","celular":"","email":"","area":"Caminar","grupo":"14","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-188","nombre":"Dorrego Onetto","apellido":"Milagros Dominga","dni":"48704967","celular":"","email":"","area":"Caminar","grupo":"14","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-189","nombre":"Bruno","apellido":"Delfina","dni":"49358326","celular":"","email":"","area":"Caminar","grupo":"14","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-190","nombre":"Pollini Ochoa","apellido":"Malena","dni":"49552185","celular":"","email":"","area":"Caminar","grupo":"14","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-191","nombre":"Fraga Mazzeo","apellido":"Gonzalo Gasto","dni":"48802741","celular":"","email":"","area":"Caminar","grupo":"14","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-192","nombre":"Sosa del Valle","apellido":"Moro","dni":"49260491","celular":"","email":"","area":"Caminar","grupo":"14","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-193","nombre":"Chambon Linares","apellido":"Clementine","dni":"49375131","celular":"","email":"","area":"Caminar","grupo":"11","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-194","nombre":"Galansky","apellido":"Victoria","dni":"49064407","celular":"","email":"","area":"Caminar","grupo":"11","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-195","nombre":"Diaz","apellido":"Violeta","dni":"48628262","celular":"","email":"","area":"Caminar","grupo":"11","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-196","nombre":"Tena","apellido":"Felipe","dni":"48245503","celular":"","email":"","area":"Caminar","grupo":"11","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-197","nombre":"Cravero Galli","apellido":"Sofia","dni":"49088419","celular":"","email":"","area":"Caminar","grupo":"11","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-198","nombre":"lagier","apellido":"francisco","dni":"48870590","celular":"","email":"","area":"Caminar","grupo":"11","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-199","nombre":"Romero Lemonnier","apellido":"Mía","dni":"49600217","celular":"","email":"","area":"Caminar","grupo":"11","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-200","nombre":"Quintana","apellido":"Matias","dni":"49552139","celular":"","email":"","area":"Caminar","grupo":"11","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-201","nombre":"Torres","apellido":"Guillermina","dni":"49156394","celular":"","email":"","area":"Caminar","grupo":"11","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-202","nombre":"Del Carril","apellido":"CAmila","dni":"48793632","celular":"","email":"","area":"Caminar","grupo":"11","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":0,"entradas_transferencia":50000,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-203","nombre":"Genoud Zocchi","apellido":"Tomás","dni":"49192467","celular":"","email":"","area":"Caminar","grupo":"11","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":130000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-204","nombre":"Millie","apellido":"Grassi tirado","dni":"48648232","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":10000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-205","nombre":"Mora Paula","apellido":"Altamirano","dni":"48387104","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":10000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-206","nombre":"Hipólito","apellido":"Bayugar","dni":"48458588","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-207","nombre":"Francisca","apellido":"Tombion","dni":"48561737","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":30000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":3,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-208","nombre":"Alma","apellido":"Devereux","dni":"48464162","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-209","nombre":"Josefina","apellido":"Mattos","dni":"48382634","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":20000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":2,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-210","nombre":"Patricio felipe","apellido":"Meza","dni":"48698443","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-211","nombre":"Milagros","apellido":"Orozco","dni":"48462229","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":50000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-212","nombre":"Sofia Isabel","apellido":"Orella","dni":"48801008","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-213","nombre":"Juana","apellido":"Bardoneschi","dni":"47963107","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-214","nombre":"Agustin","apellido":"De Panfilis","dni":"48390235","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-215","nombre":"Tobias","apellido":"Udaquiola","dni":"48240371","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":20000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":2,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-216","nombre":"Sofia","apellido":"Carrete Sambrizzi","dni":"48561671","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":10000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-217","nombre":"Matías Francisco","apellido":"Panizza","dni":"4692413","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-218","nombre":"Carolina Aylén","apellido":"Quiroga","dni":"46027773","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-219","nombre":"Santino Antonio","apellido":"Scarinci","dni":"47745670","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":50000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-220","nombre":"Vicente","apellido":"Raffo","dni":"48675163","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":30000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":3,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-221","nombre":"Agustina Micaela","apellido":"Quiles Sollner","dni":"47343135","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-222","nombre":"clara","apellido":"ret","dni":"48313579","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Debe efectivo","pago_efectivo":60000,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":6,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-223","nombre":"Tomás","apellido":"Courtaux","dni":"48432179","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":20000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":2,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-224","nombre":"Joaquín","apellido":"Fernández","dni":"48029623","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-225","nombre":"Santiago","apellido":"Latorre","dni":"48715531","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-226","nombre":"Tomas","apellido":"Gimenez","dni":"48705228","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-227","nombre":"Pilar","apellido":"Lanús Lett Brown","dni":"48178125","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-228","nombre":"Marina Taciana","apellido":"Stocik","dni":"48802463","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":50000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-229","nombre":"Fermín","apellido":"Caffarone","dni":"48307447","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":50000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-230","nombre":"Helena","apellido":"Bofill","dni":"48386278","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-231","nombre":"Tomas Alberto","apellido":"Arnaboldi Cardinal","dni":"47343396","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-232","nombre":"Juana","apellido":"Vetrano","dni":"48705220","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-233","nombre":"Carolina","apellido":"Conrad","dni":"48590118","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Debe efectivo","pago_efectivo":20000,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":2,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-234","nombre":"clara","apellido":"Vidal","dni":"48224562","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":10000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-235","nombre":"bautista","apellido":"diaz rivier","dni":"48590199","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-236","nombre":"martina","apellido":"lopez gil","dni":"48595328","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-237","nombre":"Giuliana Agustina","apellido":"Pierdominici","dni":"48214897","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":20000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":2,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-238","nombre":"Tomás","apellido":"Miguez","dni":"48561767","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-239","nombre":"Martina","apellido":"Iglesias Brickles","dni":"48578068","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":50000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-240","nombre":"Alma Maria","apellido":"Crupi","dni":"48561727","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-241","nombre":"Nicolás","apellido":"Cibeira","dni":"48705259","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":40000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":4,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-242","nombre":"Luciana","apellido":"Bedate","dni":"47940782","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-243","nombre":"Julia","apellido":"Duben","dni":"48431883","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":60000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":6,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-244","nombre":"Santiago","apellido":"Andragnes","dni":"47962978","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":50000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-245","nombre":"Catalina","apellido":"Bello","dni":"48704612","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-246","nombre":"JUAN IGNACIO","apellido":"ARGAÑARAS","dni":"47962153","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":20000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":2,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-247","nombre":"Juan Martin","apellido":"Puente","dni":"47434273","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-248","nombre":"Sofia Ines","apellido":"Canosa","dni":"48366395","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-249","nombre":"Daiana","apellido":"Perfecto Huaman","dni":"45327368","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-250","nombre":"Milagros","apellido":"Noguer tatay","dni":"48675827","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-251","nombre":"María Delfina","apellido":"Salvo","dni":"48366371","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":50000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-252","nombre":"Agustin","apellido":"Manetti","dni":"45990231","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-253","nombre":"Pilar","apellido":"Boutellier","dni":"48505147","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-254","nombre":"sofía maría","apellido":"salaberri","dni":"48224557","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":20000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":2,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-255","nombre":"Agustin Federico","apellido":"Dayen","dni":"51701455","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-256","nombre":"clemente","apellido":"ocampo","dni":"48313263","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-257","nombre":"Guadalupe","apellido":"Perotti Arbelaiz","dni":"48109251","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":10000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-258","nombre":"Benja","apellido":"Cobo","dni":"48313371","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":50000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-259","nombre":"Benjamin","apellido":"Pochat","dni":"48505143","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":20000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":2,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-260","nombre":"KEVIN LUCIANO","apellido":"CASTILLO PANTA","dni":"47018922","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Debe efectivo","pago_efectivo":10000,"pago_transferencia":40000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-261","nombre":"Roberto Tomás","apellido":"Milligan","dni":"47872479","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":50000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-262","nombre":"LUCILA CHIARA","apellido":"QUINTÁS","dni":"48113171","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":50000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-263","nombre":"francisco","apellido":"sackmann","dni":"48431821","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-264","nombre":"julieta","apellido":"cañibano","dni":"48243282","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":70000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":7,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-265","nombre":"juana","apellido":"dolezal","dni":"48231761","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-266","nombre":"Olivia","apellido":"Pimentel","dni":"48505149","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-267","nombre":"thiago agustin","apellido":"rojas falco","dni":"48628511","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-268","nombre":"Santino","apellido":"Beccace e","dni":"48431817","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-269","nombre":"Micaela","apellido":"Botto","dni":"48677507","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":20000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":2,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-270","nombre":"María Felícitas","apellido":"Alba","dni":"48680555","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-271","nombre":"Maria","apellido":"Pita","dni":"48592292","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-272","nombre":"Camila","apellido":"Carro","dni":"48522957","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-273","nombre":"Jeronimo","apellido":"Schumacher","dni":"46705452","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Debe efectivo","pago_efectivo":10000,"pago_transferencia":20000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":1,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-274","nombre":"Stefania","apellido":"Soria","dni":"48241305","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":20000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":2,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-275","nombre":"lola","apellido":"vasquez","dni":"95093992","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-276","nombre":"valentina","apellido":"levy","dni":"47091897","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":60000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":6,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-277","nombre":"Jeronimo","apellido":"Mayoral","dni":"48183881","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-278","nombre":"Ulises","apellido":"Calderon Cavalieri","dni":"48870553","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-279","nombre":"Lucas","apellido":"Clavelliere","dni":"","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-280","nombre":"Sol","apellido":"Bertholaga","dni":"","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":50000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-281","nombre":"Lucia","apellido":"Marioni","dni":"","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":30000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":3,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-282","nombre":"Franca","apellido":"Penas","dni":"","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-283","nombre":"Athina","apellido":"Quiros","dni":"","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":50000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":5,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-284","nombre":"Joaquin","apellido":"Ricotti","dni":"","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"No pagó","pago_efectivo":0,"pago_transferencia":0,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"No","cantidad_entradas":0,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-285","nombre":"Augusto","apellido":"Dichiara","dni":"","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Pagado","pago_efectivo":0,"pago_transferencia":40000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":4,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false},{"id":"ID-286","nombre":"Martiniano","apellido":"Spretz","dni":"","celular":"","email":"","area":"Ágora","grupo":"Ágora","rol":"participante","estado":"Parcial","pago_efectivo":0,"pago_transferencia":20000,"precio":40000,"comprobante":"No","autorizacion":"No","vendio_entradas":"Sí","cantidad_entradas":2,"entradas_efectivo":0,"entradas_transferencia":0,"entro_plata":"No","observaciones":"","asistencia":false}]
;

// ─── CONFIG ──────────────────────────────────────────────────────────────────
const AREAS = {
  "Caminar":        { precio: 130000, color: "#2563eb", bg: "#eff6ff",  emoji: "🚶" },
  "Confirmación":   { precio: 130000, color: "#8b5cf6", bg: "#f5f3ff",  emoji: "✨" },
  "Preconfirmación":{ precio: 130000, color: "#f59e0b", bg: "#fffbeb",  emoji: "🌱" },
  "Ágora":          { precio: 40000,  color: "#ec4899", bg: "#fdf2f8",  emoji: "🎭" },
};

const ESTADO_CFG = {
  "Pagado":        { bg:"#dcfce7", text:"#15803d", dot:"#22c55e", label:"Pagado" },
  "Parcial":       { bg:"#fef9c3", text:"#a16207", dot:"#eab308", label:"Parcial" },
  "No pagó":       { bg:"#fee2e2", text:"#dc2626", dot:"#ef4444", label:"No pagó" },
  "Debe efectivo": { bg:"#ffedd5", text:"#c2410c", dot:"#f97316", label:"Debe" },
};

const $ar = n => `$${Number(n||0).toLocaleString("es-AR")}`;

// ─── ICONS ────────────────────────────────────────────────────────────────────
const I = ({ n, s=20, c="currentColor" }) => {
  const p = {
    home:    "M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z M9 22V12h6v10",
    users:   "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2 M23 21v-2a4 4 0 0 0-3-3.87 M16 3.13a4 4 0 0 1 0 7.75 M9 7m-4 0a4 4 0 1 0 8 0a4 4 0 1 0-8 0",
    dollar:  "M12 1v22 M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",
    ticket:  "M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2z M9 12h6",
    check:   "M20 6L9 17 4 12",
    more:    "M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0-2 0 M19 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0-2 0 M5 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0-2 0",
    search:  "M11 11m-8 0a8 8 0 1 0 16 0a8 8 0 1 0-16 0 M21 21l-4.35-4.35",
    back:    "M19 12H5 M12 19l-7-7 7-7",
    plus:    "M12 5v14 M5 12h14",
    edit:    "M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7 M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4z",
    x:       "M18 6L6 18 M6 6l12 12",
    trophy:  "M8 21l4-4 4 4 M12 17v-6 M7 4h10v7a5 5 0 0 1-10 0z M17 4h3v3a3 3 0 0 1-3 3 M7 4H4v3a3 3 0 0 0 3 3",
    alert:   "M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z M12 9v4 M12 17h.01",
    save:    "M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z M17 21V13H7v8 M7 3v5h8",
    logout:  "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4 M16 17l5-5-5-5 M21 12H9",
    phone:   "M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.11 2 2 0 0 1 3.6 1h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6z",
    mail:    "M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z M22 6l-10 7L2 6",
    star:    "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01z",
    group:   "M3 3h7v7H3z M14 3h7v7h-7z M14 14h7v7h-7z M3 14h7v7H3z",
    coord:   "M12 2a5 5 0 1 0 0 10 5 5 0 0 0 0-10z M2 21a10 10 0 0 1 20 0",
    id:      "M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z M8 10h8 M8 14h4",
    down:    "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4 M7 10l5 5 5-5 M12 15V3",
    up:      "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4 M17 8l-5-5-5 5 M12 3v12",
    filter:  "M22 3H2l8 9.46V19l4 2v-8.54z",
    walk:    "M13 4a1 1 0 1 0 2 0 1 1 0 0 0-2 0 M7.5 21l3-5.5 2.5 2 3-7 M5 12l2.5-5.5L11 8l2-4",
    agora:   "M2 20h20 M4 20V10l8-6 8 6v10",
  };
  const d = p[n] || "";
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
      {d.split(" M").map((seg, i) => <path key={i} d={(i===0?'':'M')+seg}/>)}
    </svg>
  );
};

// ─── DONUT ────────────────────────────────────────────────────────────────────
const Donut = ({ segs, size=80, label="" }) => {
  const total = segs.reduce((s,d) => s+d.v, 0) || 1;
  let angle = -90;
  const cx=size/2, cy=size/2, r=size*.36, sw=size*.16;
  const toRad = a => a*Math.PI/180;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      {segs.map((seg,i) => {
        const pct=seg.v/total, sweep=pct*360;
        if(pct<=0){angle+=sweep;return null;}
        const x1=cx+r*Math.cos(toRad(angle)), y1=cy+r*Math.sin(toRad(angle));
        angle+=sweep;
        const x2=cx+r*Math.cos(toRad(angle)), y2=cy+r*Math.sin(toRad(angle));
        return <path key={i} d={`M ${x1} ${y1} A ${r} ${r} 0 ${sweep>180?1:0} 1 ${x2} ${y2}`} fill="none" stroke={seg.c} strokeWidth={sw} strokeLinecap="round"/>;
      })}
      <text x={cx} y={cy-3} textAnchor="middle" dominantBaseline="middle" style={{fontSize:size*.2,fontWeight:800,fill:"#1e293b"}}>{total}</text>
      <text x={cx} y={cy+size*.16} textAnchor="middle" dominantBaseline="middle" style={{fontSize:size*.11,fill:"#94a3b8"}}>{label}</text>
    </svg>
  );
};

// ─── BAR CHART ────────────────────────────────────────────────────────────────
const Bars = ({ data, height=52 }) => {
  const max = Math.max(...data.map(d=>d.v),1);
  return (
    <div style={{display:"flex",alignItems:"flex-end",gap:5,height,paddingTop:4}}>
      {data.map((d,i) => (
        <div key={i} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:3}}>
          <span style={{fontSize:10,fontWeight:700,color:d.c}}>{d.v}</span>
          <div style={{width:"100%",background:d.c,borderRadius:4,height:Math.max((d.v/max)*(height-20),4),opacity:.85,transition:"height .4s"}}/>
          <span style={{fontSize:9,color:"#94a3b8",fontWeight:600,textAlign:"center",lineHeight:1.1}}>{d.l}</span>
        </div>
      ))}
    </div>
  );
};

// ─── STYLES ───────────────────────────────────────────────────────────────────
const S = {
  app:  {display:"flex",flexDirection:"column",height:"100vh",background:"#f1f5f9",fontFamily:"\'SF Pro Display\',-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif",maxWidth:430,margin:"0 auto",position:"relative",overflow:"hidden"},
  hdr:  {display:"flex",justifyContent:"space-between",alignItems:"center",padding:"14px 16px 12px",background:"white",borderBottom:"1px solid #e2e8f0",flexShrink:0},
  scrl: {flex:1,overflowY:"auto",WebkitOverflowScrolling:"touch"},
  card: {background:"white",borderRadius:16,padding:16,boxShadow:"0 1px 6px rgba(0,0,0,0.06)"},
  ibtn: {background:"#f8fafc",border:"none",borderRadius:10,padding:8,cursor:"pointer",display:"flex",alignItems:"center",gap:4},
  lbl:  {display:"block",fontSize:11,fontWeight:700,color:"#64748b",marginBottom:5,textTransform:"uppercase",letterSpacing:.4},
  inp:  {width:"100%",padding:"11px 13px",borderRadius:11,border:"1.5px solid #e2e8f0",fontSize:14,background:"#f8fafc",color:"#1e293b",outline:"none",boxSizing:"border-box",appearance:"none",WebkitAppearance:"none"},
  btn:  {display:"inline-flex",alignItems:"center",gap:6,background:"#1e3a5f",color:"white",border:"none",borderRadius:11,padding:"10px 18px",fontSize:13,fontWeight:700,cursor:"pointer"},
};

// ─── LOGIN ────────────────────────────────────────────────────────────────────
const USERS = [
  {email:"admin@retiro.com",  pass:"admin123", name:"Administrador",    role:"Admin"},
  {email:"coord@retiro.com",  pass:"coord123", name:"Coordinador",      role:"Coord"},
  {email:"part@retiro.com",   pass:"part123",  name:"Participante",     role:"Part"},
];

function Login({onLogin}) {
  const [email,setEmail]=useState(""), [pass,setPass]=useState(""), [err,setErr]=useState("");
  const go = () => {
    const u = USERS.find(u=>u.email===email&&u.pass===pass);
    if(u) onLogin(u); else setErr("Datos incorrectos");
  };
  return (
    <div style={{minHeight:"100vh",background:"linear-gradient(160deg,#0f172a 0%,#1e3a5f 60%,#0f4c81 100%)",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24}}>
      <div style={{marginBottom:28,textAlign:"center"}}>
        <div style={{fontSize:52,marginBottom:6}}>✝️</div>
        <div style={{fontSize:28,fontWeight:900,color:"white",letterSpacing:-1}}>RetiroApp</div>
        <div style={{fontSize:13,color:"#94a3b8",marginTop:4}}>Sistema de gestión de retiros espirituales</div>
      </div>
      <div style={{background:"white",borderRadius:22,padding:28,width:"100%",maxWidth:360,boxShadow:"0 24px 64px rgba(0,0,0,.35)"}}>
        <div style={{marginBottom:14}}>
          <label style={S.lbl}>Email</label>
          <input style={S.inp} type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="tu@email.com"/>
        </div>
        <div style={{marginBottom:18}}>
          <label style={S.lbl}>Contraseña</label>
          <input style={S.inp} type="password" value={pass} onChange={e=>setPass(e.target.value)} placeholder="••••••••" onKeyDown={e=>e.key==="Enter"&&go()}/>
        </div>
        {err && <div style={{color:"#dc2626",fontSize:13,marginBottom:10,textAlign:"center"}}>{err}</div>}
        <button style={{...S.btn,width:"100%",justifyContent:"center",padding:14,fontSize:15}} onClick={go}>Ingresar</button>
        <div style={{marginTop:16,background:"#f8fafc",borderRadius:10,padding:12,fontSize:11,color:"#64748b"}}>
          <b>Demo:</b> admin@retiro.com / admin123
        </div>
      </div>
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [user,setUser]=useState(null);
  const [tab,setTab]=useState("home");
  const [parts,setParts]=useState(ALL_DATA.map((p,i)=>({...p,id:p.id||`ID-${i}`})));
  const [selected,setSelected]=useState(null);
  const [editMode,setEditMode]=useState(false);
  const [editData,setEditData]=useState(null);
  const [addModal,setAddModal]=useState(false);
  const [newP,setNewP]=useState({nombre:"",apellido:"",dni:"",celular:"",email:"",area:"Caminar",grupo:"1",rol:"participante",estado:"No pagó",pago_efectivo:0,pago_transferencia:0,precio:130000,comprobante:"No",autorizacion:"No",vendio_entradas:"No",cantidad_entradas:0,entradas_efectivo:0,entradas_transferencia:0,entro_plata:"No",observaciones:"",asistencia:false});
  const [toast,setToast]=useState(null);

  const showToast = (msg,type="ok") => { setToast({msg,type}); setTimeout(()=>setToast(null),2500); };

  const stats = useMemo(()=>{
    const total=parts.length;
    const pagados=parts.filter(p=>p.estado==="Pagado").length;
    const parciales=parts.filter(p=>p.estado==="Parcial").length;
    const noPago=parts.filter(p=>p.estado==="No pagó").length;
    const debe=parts.filter(p=>p.estado==="Debe efectivo").length;
    const recaudado=parts.reduce((s,p)=>s+(p.pago_efectivo||0)+(p.pago_transferencia||0),0);
    const entradas=parts.reduce((s,p)=>s+(p.cantidad_entradas||0),0);
    const recEntradas=parts.reduce((s,p)=>s+(p.entradas_efectivo||0)+(p.entradas_transferencia||0),0);
    const presentes=parts.filter(p=>p.asistencia).length;
    const deuda=parts.filter(p=>p.estado!=="Pagado").reduce((s,p)=>s+Math.max((p.precio||0)-((p.pago_efectivo||0)+(p.pago_transferencia||0)),0),0);
    const byCaminar=parts.filter(p=>p.area==="Caminar");
    const byAgora=parts.filter(p=>p.area==="Ágora");
    return {total,pagados,parciales,noPago,debe,recaudado,entradas,recEntradas,presentes,deuda,
      caminarCount:byCaminar.length, agoraCount:byAgora.length,
      caminarRec:byCaminar.reduce((s,p)=>s+(p.pago_efectivo||0)+(p.pago_transferencia||0),0),
      agoraRec:byAgora.reduce((s,p)=>s+(p.pago_efectivo||0)+(p.pago_transferencia||0),0),
    };
  },[parts]);

  const grupos14 = useMemo(()=>
    [...new Set(parts.filter(p=>p.area==="Caminar"&&p.rol==="participante").map(p=>p.grupo))].sort((a,b)=>Number(a)-Number(b))
  ,[parts]);

  const saveEdit = () => { setParts(prev=>prev.map(p=>p.id===editData.id?editData:p)); setSelected(editData); setEditMode(false); showToast("Guardado ✓"); };
  const toggleAsis = id => { setParts(prev=>prev.map(p=>p.id===id?{...p,asistencia:!p.asistencia}:p)); };
  const addPart = () => {
    if(!newP.nombre.trim()){showToast("Nombre obligatorio","err");return;}
    setParts(prev=>[...prev,{...newP,id:`ID-${Date.now()}`,precio:AREAS[newP.area]?.precio||130000}]);
    setAddModal(false);
    setNewP({nombre:"",apellido:"",dni:"",celular:"",email:"",area:"Caminar",grupo:"1",rol:"participante",estado:"No pagó",pago_efectivo:0,pago_transferencia:0,precio:130000,comprobante:"No",autorizacion:"No",vendio_entradas:"No",cantidad_entradas:0,entradas_efectivo:0,entradas_transferencia:0,entro_plata:"No",observaciones:"",asistencia:false});
    showToast("Participante agregado ✓");
  };

  if(!user) return <Login onLogin={setUser}/>;

  if(selected) {
    if(editMode&&editData) return (
      <div style={S.app}>
        <div style={S.hdr}>
          <button style={S.ibtn} onClick={()=>{setEditMode(false);setEditData(null);}}><I n="x" s={20}/></button>
          <span style={{fontSize:16,fontWeight:800,color:"#1e293b"}}>Editar participante</span>
          <button style={{...S.btn,padding:"7px 16px",fontSize:13}} onClick={saveEdit}>Guardar</button>
        </div>
        <div style={{...S.scrl,padding:"16px 16px 100px"}}><EditForm data={editData} onChange={setEditData}/></div>
      </div>
    );
    return <Detail p={selected} onBack={()=>setSelected(null)} onEdit={()=>{setEditData({...selected});setEditMode(true);}} onToggle={toggleAsis}/>;
  }

  return (
    <div style={S.app}>
      {toast && (
        <div style={{position:"fixed",top:20,left:"50%",transform:"translateX(-50%)",zIndex:999,background:toast.type==="err"?"#fee2e2":"#dcfce7",color:toast.type==="err"?"#dc2626":"#15803d",padding:"10px 20px",borderRadius:12,fontWeight:700,fontSize:14,boxShadow:"0 4px 20px rgba(0,0,0,.14)",border:`1px solid ${toast.type==="err"?"#fca5a5":"#86efac"}`,whiteSpace:"nowrap"}}>
          {toast.msg}
        </div>
      )}
      {/* HEADER */}
      <div style={S.hdr}>
        <div>
          <div style={{fontSize:11,color:"#94a3b8",fontWeight:500}}>Bienvenido/a</div>
          <div style={{fontSize:17,fontWeight:900,color:"#1e293b"}}>{user.name}</div>
        </div>
        <div style={{display:"flex",gap:8,alignItems:"center"}}>
          <span style={{background:"#f1f5f9",borderRadius:8,padding:"3px 10px",fontSize:11,color:"#475569",fontWeight:700}}>{user.role}</span>
          <button style={{...S.ibtn,background:"transparent"}} onClick={()=>setUser(null)}><I n="logout" s={18} c="#94a3b8"/></button>
        </div>
      </div>

      {/* CONTENT */}
      <div style={{...S.scrl,paddingBottom:80}}>
        {tab==="home"       && <HomeTab stats={stats} onNav={setTab} onAdd={()=>setAddModal(true)}/>}
        {tab==="partic"     && <ParticTab parts={parts} grupos14={grupos14} onSelect={setSelected} onAdd={()=>setAddModal(true)}/>}
        {tab==="pagos"      && <PagosTab parts={parts} stats={stats}/>}
        {tab==="entradas"   && <EntradasTab parts={parts}/>}
        {tab==="asistencia" && <AsisTab parts={parts} grupos14={grupos14} onToggle={toggleAsis} stats={stats} showToast={showToast}/>}
        {tab==="mas"        && <MasTab user={user} stats={stats} onLogout={()=>setUser(null)}/>}
      </div>

      {/* ADD MODAL */}
      {addModal && (
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.5)",zIndex:100,display:"flex",flexDirection:"column",justifyContent:"flex-end"}}>
          <div style={{background:"white",borderRadius:"20px 20px 0 0",padding:"22px 16px 40px",maxHeight:"88vh",overflowY:"auto"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18}}>
              <span style={{fontSize:18,fontWeight:900,color:"#1e293b"}}>Nuevo participante</span>
              <button onClick={()=>setAddModal(false)}><I n="x" s={22} c="#64748b"/></button>
            </div>
            <EditForm data={newP} onChange={setNewP}/>
            <button style={{...S.btn,width:"100%",justifyContent:"center",marginTop:14,padding:13}} onClick={addPart}>Agregar participante</button>
          </div>
        </div>
      )}

      <BottomNav tab={tab} setTab={setTab}/>
    </div>
  );
}

// ─── HOME TAB ─────────────────────────────────────────────────────────────────
function HomeTab({stats,onNav,onAdd}) {
  return (
    <div style={{padding:"16px 16px 0"}}>
      {/* Hero recaudación */}
      <div style={{background:"linear-gradient(135deg,#0f172a,#1e3a5f)",borderRadius:20,padding:"20px 20px 16px",marginBottom:12,color:"white"}}>
        <div style={{fontSize:12,opacity:.7,marginBottom:2}}>Total recaudado</div>
        <div style={{fontSize:32,fontWeight:900,letterSpacing:-1}}>{$ar(stats.recaudado)}</div>
        <div style={{display:"flex",gap:20,marginTop:14,paddingTop:14,borderTop:"1px solid rgba(255,255,255,.12)"}}>
          <div><div style={{fontSize:10,opacity:.6}}>Caminar</div><div style={{fontSize:15,fontWeight:800}}>{$ar(stats.caminarRec)}</div></div>
          <div><div style={{fontSize:10,opacity:.6}}>Ágora</div><div style={{fontSize:15,fontWeight:800}}>{$ar(stats.agoraRec)}</div></div>
          <div><div style={{fontSize:10,opacity:.6,color:"#fca5a5"}}>Deuda</div><div style={{fontSize:15,fontWeight:800,color:"#fca5a5"}}>{$ar(stats.deuda)}</div></div>
        </div>
      </div>

      {/* Stat grid */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:10}}>
        <Stat l="Total partic." v={stats.total}   c="#3b82f6" sub={`${stats.caminarCount} Caminar · ${stats.agoraCount} Ágora`}/>
        <Stat l="Pagados"       v={stats.pagados}  c="#22c55e"/>
        <Stat l="Parciales"     v={stats.parciales} c="#eab308"/>
        <Stat l="Sin pagar"     v={stats.noPago+stats.debe} c="#ef4444"/>
      </div>

      {/* Donut + Bars */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:10}}>
        <div style={{...S.card}}>
          <div style={{fontSize:11,fontWeight:800,color:"#94a3b8",marginBottom:8}}>DISTRIBUCIÓN</div>
          <div style={{display:"flex",justifyContent:"center"}}>
            <Donut segs={[{v:stats.pagados,c:"#22c55e"},{v:stats.parciales,c:"#eab308"},{v:stats.noPago,c:"#ef4444"},{v:stats.debe,c:"#f97316"}]} size={88} label="total"/>
          </div>
          <div style={{display:"flex",flexWrap:"wrap",gap:"4px 8px",marginTop:8}}>
            {[["#22c55e","Pagado"],["#eab308","Parcial"],["#ef4444","No pagó"],["#f97316","Debe"]].map(([c,l])=>(
              <div key={l} style={{display:"flex",alignItems:"center",gap:3,fontSize:10}}>
                <div style={{width:7,height:7,borderRadius:"50%",background:c}}/><span style={{color:"#64748b"}}>{l}</span>
              </div>
            ))}
          </div>
        </div>
        <div style={{...S.card}}>
          <div style={{fontSize:11,fontWeight:800,color:"#94a3b8",marginBottom:4}}>PAGOS</div>
          <Bars data={[{v:stats.pagados,c:"#22c55e",l:"Pago"},{v:stats.parciales,c:"#eab308",l:"Parc."},{v:stats.noPago,c:"#ef4444",l:"No"},{v:stats.debe,c:"#f97316",l:"Debe"}]}/>
          <div style={{marginTop:8,paddingTop:8,borderTop:"1px solid #f1f5f9"}}>
            <div style={{fontSize:10,color:"#94a3b8"}}>Entradas vendidas</div>
            <div style={{fontSize:18,fontWeight:900,color:"#8b5cf6"}}>{stats.entradas} <span style={{fontSize:11,fontWeight:500,color:"#94a3b8"}}>boletos</span></div>
          </div>
        </div>
      </div>

      {/* Áreas */}
      <div style={{fontSize:12,fontWeight:800,color:"#94a3b8",marginBottom:8}}>ÁREAS</div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:12}}>
        {Object.entries(AREAS).map(([a,cfg])=>{
          const ps=parts_placeholder.filter(p=>p.area===a);
          return (
            <div key={a} style={{background:cfg.bg,borderRadius:14,padding:14,border:`1px solid ${cfg.color}22`}}>
              <div style={{fontSize:18,marginBottom:4}}>{cfg.emoji}</div>
              <div style={{fontSize:13,fontWeight:800,color:cfg.color}}>{a}</div>
              <div style={{fontSize:11,color:"#64748b",marginTop:2}}>{cfg.precio===40000?"$40.000":"$130.000"} · {ps.length} personas</div>
            </div>
          );
        })}
      </div>

      {/* Asistencia */}
      <div style={{...S.card,marginBottom:12,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <div style={{fontSize:11,fontWeight:800,color:"#94a3b8"}}>ASISTENCIA</div>
          <div style={{fontSize:22,fontWeight:900,color:"#1e293b",marginTop:2}}>{stats.presentes}<span style={{fontSize:13,color:"#64748b",fontWeight:500}}> / {stats.total}</span></div>
        </div>
        <div style={{position:"relative",width:60,height:60}}>
          <svg viewBox="0 0 60 60" width={60} height={60}>
            <circle cx={30} cy={30} r={24} fill="none" stroke="#e2e8f0" strokeWidth={7}/>
            <circle cx={30} cy={30} r={24} fill="none" stroke="#3b82f6" strokeWidth={7}
              strokeDasharray={`${(stats.presentes/Math.max(stats.total,1))*150.8} 150.8`}
              strokeLinecap="round" transform="rotate(-90 30 30)"/>
          </svg>
          <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,fontWeight:800,color:"#1e3a5f"}}>
            {Math.round((stats.presentes/Math.max(stats.total,1))*100)}%
          </div>
        </div>
      </div>

      {/* Acciones rápidas */}
      <div style={{fontSize:12,fontWeight:800,color:"#94a3b8",marginBottom:8}}>ACCIONES RÁPIDAS</div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,marginBottom:16}}>
        {[
          {i:"plus",l:"Agregar",c:"#3b82f6",a:onAdd},
          {i:"users",l:"Personas",c:"#8b5cf6",a:()=>onNav("partic")},
          {i:"check",l:"Asistencia",c:"#22c55e",a:()=>onNav("asistencia")},
          {i:"dollar",l:"Pagos",c:"#f59e0b",a:()=>onNav("pagos")},
          {i:"ticket",l:"Entradas",c:"#ec4899",a:()=>onNav("entradas")},
          {i:"down",l:"Exportar",c:"#64748b",a:()=>alert("Próximamente")},
        ].map(x=>(
          <button key={x.l} onClick={x.a} style={{background:"white",border:"none",borderRadius:14,padding:"13px 6px",display:"flex",flexDirection:"column",alignItems:"center",gap:5,cursor:"pointer",boxShadow:"0 1px 6px rgba(0,0,0,.07)"}}>
            <div style={{background:x.c+"18",borderRadius:10,padding:9}}><I n={x.i} s={18} c={x.c}/></div>
            <span style={{fontSize:11,fontWeight:600,color:"#475569"}}>{x.l}</span>
          </button>
        ))}
      </div>

      {(stats.noPago+stats.debe)>0 && (
        <div style={{background:"#fff7ed",border:"1px solid #fed7aa",borderRadius:14,padding:14,marginBottom:20,display:"flex",gap:10,alignItems:"flex-start"}}>
          <I n="alert" s={18} c="#f97316"/>
          <div>
            <div style={{fontSize:13,fontWeight:700,color:"#c2410c"}}>⚠️ Deudores pendientes</div>
            <div style={{fontSize:12,color:"#9a3412",marginTop:2}}>{stats.noPago+stats.debe} participantes con pago incompleto · Deuda total: {$ar(stats.deuda)}</div>
          </div>
        </div>
      )}
    </div>
  );
}
// placeholder needed in HomeTab closure
const parts_placeholder = ALL_DATA;

function Stat({l,v,c,sub}) {
  return (
    <div style={{...S.card,display:"flex",alignItems:"center",gap:11}}>
      <div style={{background:c+"18",borderRadius:11,padding:10,flexShrink:0}}>
        <div style={{width:6,height:6,borderRadius:"50%",background:c,margin:"auto"}}/>
      </div>
      <div style={{minWidth:0}}>
        <div style={{fontSize:24,fontWeight:900,color:"#1e293b",lineHeight:1}}>{v}</div>
        <div style={{fontSize:11,color:"#64748b",marginTop:1}}>{l}</div>
        {sub && <div style={{fontSize:10,color:"#94a3b8",marginTop:2}}>{sub}</div>}
      </div>
    </div>
  );
}

// ─── PARTICIPANTES TAB ────────────────────────────────────────────────────────
function ParticTab({parts,grupos14,onSelect,onAdd}) {
  const [q,setQ]=useState("");
  const [fEstado,setFEstado]=useState("all");
  const [fArea,setFArea]=useState("all");
  const [fGrupo,setFGrupo]=useState("all");
  const [fRol,setFRol]=useState("all");

  const filtered = useMemo(()=>parts.filter(p=>{
    const txt=q.toLowerCase();
    const mQ=!txt||`${p.nombre} ${p.apellido} ${p.dni} ${p.grupo}`.toLowerCase().includes(txt);
    const mE=fEstado==="all"||p.estado===fEstado;
    const mA=fArea==="all"||p.area===fArea;
    const mG=fGrupo==="all"||p.grupo===fGrupo;
    const mR=fRol==="all"||p.rol===fRol;
    return mQ&&mE&&mA&&mG&&mR;
  }),[parts,q,fEstado,fArea,fGrupo,fRol]);

  return (
    <div style={{padding:"14px 14px 0"}}>
      {/* Search */}
      <div style={{position:"relative",marginBottom:10}}>
        <div style={{position:"absolute",left:11,top:"50%",transform:"translateY(-50%)"}}><I n="search" s={15} c="#94a3b8"/></div>
        <input style={{...S.inp,paddingLeft:34,background:"white"}} value={q} onChange={e=>setQ(e.target.value)} placeholder="Nombre, apellido, DNI, grupo..."/>
      </div>

      {/* Estado chips */}
      <div style={{display:"flex",gap:6,marginBottom:10,overflowX:"auto",paddingBottom:2}}>
        {["all","Pagado","Parcial","No pagó","Debe efectivo"].map(e=>(
          <button key={e} onClick={()=>setFEstado(e)} style={{flexShrink:0,padding:"5px 13px",borderRadius:20,border:"none",background:fEstado===e?"#1e3a5f":"#f1f5f9",color:fEstado===e?"white":"#64748b",fontSize:12,fontWeight:600,cursor:"pointer"}}>
            {e==="all"?"Todos":e}
          </button>
        ))}
      </div>

      {/* Filters row */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:6,marginBottom:12}}>
        <select style={{...S.inp,fontSize:12,padding:"9px 10px"}} value={fArea} onChange={e=>{setFArea(e.target.value);setFGrupo("all");}}>
          <option value="all">Todas las áreas</option>
          {Object.keys(AREAS).map(a=><option key={a} value={a}>{a}</option>)}
        </select>
        <select style={{...S.inp,fontSize:12,padding:"9px 10px"}} value={fGrupo} onChange={e=>setFGrupo(e.target.value)}>
          <option value="all">Todos los grupos</option>
          {(fArea==="Caminar"||fArea==="all")?grupos14.map(g=><option key={g} value={g}>Grupo {g}</option>):null}
          {(fArea==="Ágora"||fArea==="all")?<option value="Ágora">Ágora</option>:null}
        </select>
        <select style={{...S.inp,fontSize:12,padding:"9px 10px"}} value={fRol} onChange={e=>setFRol(e.target.value)}>
          <option value="all">Todos</option>
          <option value="participante">Participantes</option>
          <option value="coordinador">Coordinadores</option>
        </select>
      </div>

      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
        <span style={{fontSize:13,color:"#64748b",fontWeight:600}}>{filtered.length} de {parts.length}</span>
        <button style={{...S.btn,padding:"8px 14px",fontSize:12}} onClick={onAdd}><I n="plus" s={13} c="white"/> Agregar</button>
      </div>

      <div style={{display:"flex",flexDirection:"column",gap:8,paddingBottom:8}}>
        {filtered.map(p=><PCard key={p.id} p={p} onClick={()=>onSelect(p)}/>)}
        {filtered.length===0 && <div style={{textAlign:"center",color:"#94a3b8",padding:40,fontSize:14}}>Sin resultados</div>}
      </div>
    </div>
  );
}

function PCard({p,onClick}) {
  const est=ESTADO_CFG[p.estado]||ESTADO_CFG["No pagó"];
  const areaCfg=AREAS[p.area]||AREAS["Caminar"];
  const totalPagado=(p.pago_efectivo||0)+(p.pago_transferencia||0);
  const deuda=Math.max((p.precio||0)-totalPagado,0);
  return (
    <div onClick={onClick} style={{background:"white",borderRadius:16,padding:14,boxShadow:"0 1px 6px rgba(0,0,0,.06)",cursor:"pointer",border:`1px solid ${areaCfg.color}18`}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:8}}>
        <div style={{flex:1,minWidth:0}}>
          <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:2}}>
            {p.rol==="coordinador" && <span style={{background:"#fef3c7",color:"#d97706",fontSize:9,fontWeight:800,padding:"1px 6px",borderRadius:20,flexShrink:0}}>COORD</span>}
            <span style={{fontSize:15,fontWeight:700,color:"#1e293b",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{p.nombre} {p.apellido}</span>
          </div>
          <div style={{display:"flex",gap:6,alignItems:"center",flexWrap:"wrap"}}>
            <span style={{background:areaCfg.bg,color:areaCfg.color,fontSize:10,fontWeight:700,padding:"2px 8px",borderRadius:20}}>{areaCfg.emoji} {p.area}</span>
            <span style={{fontSize:12,color:"#64748b"}}>G.{p.grupo}</span>
            {p.dni && <span style={{fontSize:11,color:"#94a3b8"}}>DNI {p.dni}</span>}
          </div>
        </div>
        <div style={{background:est.bg,color:est.text,fontSize:11,fontWeight:700,padding:"4px 10px",borderRadius:20,flexShrink:0,whiteSpace:"nowrap"}}>{est.label}</div>
      </div>
      <div style={{display:"flex",gap:14,marginTop:10,paddingTop:10,borderTop:"1px solid #f8fafc",flexWrap:"wrap"}}>
        <div style={{fontSize:12}}><span style={{color:"#94a3b8"}}>Pagado: </span><span style={{fontWeight:700,color:"#1e293b"}}>{$ar(totalPagado)}</span></div>
        <div style={{fontSize:12}}><span style={{color:"#94a3b8"}}>Precio: </span><span style={{fontWeight:600,color:areaCfg.color}}>{$ar(p.precio)}</span></div>
        {deuda>0 && <div style={{fontSize:12}}><span style={{color:"#ef4444",fontWeight:700}}>Debe {$ar(deuda)}</span></div>}
        {p.cantidad_entradas>0 && <div style={{fontSize:12}}><span style={{color:"#8b5cf6",fontWeight:700}}>{p.cantidad_entradas} 🎟</span></div>}
        {p.asistencia && <div style={{fontSize:12,color:"#22c55e",fontWeight:700}}>✓ Presente</div>}
      </div>
    </div>
  );
}

// ─── DETAIL VIEW ──────────────────────────────────────────────────────────────
function Detail({p,onBack,onEdit,onToggle}) {
  const est=ESTADO_CFG[p.estado]||ESTADO_CFG["No pagó"];
  const areaCfg=AREAS[p.area]||AREAS["Caminar"];
  const totalPagado=(p.pago_efectivo||0)+(p.pago_transferencia||0);
  const deuda=Math.max((p.precio||0)-totalPagado,0);
  const totalEntradas=(p.entradas_efectivo||0)+(p.entradas_transferencia||0);
  return (
    <div style={S.app}>
      <div style={S.hdr}>
        <button style={S.ibtn} onClick={onBack}><I n="back" s={21}/></button>
        <span style={{fontSize:16,fontWeight:800,color:"#1e293b"}}>Ficha</span>
        <button style={{...S.btn,padding:"7px 14px",fontSize:12}} onClick={onEdit}><I n="edit" s={13} c="white"/> Editar</button>
      </div>
      <div style={{...S.scrl,padding:"16px 16px 100px"}}>
        {/* Hero */}
        <div style={{background:`linear-gradient(135deg,${areaCfg.color},${areaCfg.color}bb)`,borderRadius:20,padding:20,marginBottom:14,color:"white"}}>
          <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:4}}>
            {p.rol==="coordinador" && <span style={{background:"rgba(255,255,255,.25)",fontSize:10,fontWeight:800,padding:"2px 8px",borderRadius:20}}>COORDINADOR</span>}
          </div>
          <div style={{fontSize:22,fontWeight:900,lineHeight:1.2}}>{p.nombre} {p.apellido}</div>
          <div style={{fontSize:13,opacity:.85,marginTop:3}}>{areaCfg.emoji} {p.area} · Grupo {p.grupo}</div>
          <div style={{marginTop:12,display:"flex",gap:8,flexWrap:"wrap"}}>
            <span style={{background:"rgba(255,255,255,.2)",borderRadius:20,padding:"5px 14px",fontSize:13,fontWeight:700}}>{p.estado}</span>
            <span style={{background:"rgba(255,255,255,.2)",borderRadius:20,padding:"5px 14px",fontSize:13,fontWeight:700}}>Precio: {$ar(p.precio)}</span>
          </div>
        </div>

        {/* Datos personales */}
        <Sec title="Datos personales">
          {p.dni     && <IR icon="id"    label="DNI"     val={p.dni}/>}
          {p.celular && <IR icon="phone" label="Celular" val={p.celular}/>}
          {p.email   && <IR icon="mail"  label="Email"   val={p.email}/>}
          {!p.dni&&!p.celular&&!p.email && <div style={{fontSize:13,color:"#94a3b8",fontStyle:"italic"}}>Sin datos de contacto cargados</div>}
        </Sec>

        {/* Pago */}
        <Sec title={`Pago retiro (${$ar(p.precio)})`}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:10}}>
            <MBox label="Efectivo"      v={p.pago_efectivo}/>
            <MBox label="Transferencia" v={p.pago_transferencia}/>
            <MBox label="Total pagado"  v={totalPagado} hi/>
            <MBox label="Deuda"         v={deuda} color={deuda>0?"#ef4444":"#22c55e"}/>
          </div>
          <div style={{display:"flex",gap:16}}>
            <div style={{fontSize:12}}><span style={{color:"#94a3b8"}}>Comprobante: </span><span style={{fontWeight:700,color:p.comprobante==="Sí"?"#22c55e":"#ef4444"}}>{p.comprobante}</span></div>
            <div style={{fontSize:12}}><span style={{color:"#94a3b8"}}>Entró plata: </span><span style={{fontWeight:700,color:p.entro_plata==="Sí"?"#22c55e":"#94a3b8"}}>{p.entro_plata}</span></div>
          </div>
        </Sec>

        {/* Entradas */}
        <Sec title="Entradas vendidas">
          {p.cantidad_entradas>0 ? (
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              <MBox label="Cantidad" v={p.cantidad_entradas} prefix="" suffix=" boletos"/>
              <MBox label="Total"    v={totalEntradas} hi/>
              <MBox label="Efectivo" v={p.entradas_efectivo}/>
              <MBox label="Transf."  v={p.entradas_transferencia}/>
            </div>
          ) : (
            <div style={{fontSize:13,color:"#94a3b8",fontStyle:"italic"}}>No vendió entradas</div>
          )}
        </Sec>

        {/* Estado */}
        <Sec title="Estado general">
          <div style={{display:"flex",gap:16,flexWrap:"wrap",marginBottom:14}}>
            <StatusChip label="Autorización" val={p.autorizacion}/>
            <StatusChip label="Comprobante"  val={p.comprobante}/>
            <StatusChip label="Entró plata"  val={p.entro_plata}/>
          </div>
          <button onClick={()=>onToggle(p.id)} style={{width:"100%",padding:"13px",borderRadius:12,border:"none",background:p.asistencia?"#dcfce7":"#f1f5f9",color:p.asistencia?"#15803d":"#475569",fontWeight:700,fontSize:14,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>
            <I n="check" s={16} c={p.asistencia?"#15803d":"#94a3b8"}/>
            {p.asistencia?"✓ Presente · Marcar ausente":"Marcar como presente"}
          </button>
        </Sec>

        {p.observaciones && (
          <Sec title="Observaciones">
            <div style={{fontSize:14,color:"#475569",lineHeight:1.6,background:"#f8fafc",borderRadius:10,padding:12}}>{p.observaciones}</div>
          </Sec>
        )}
      </div>
    </div>
  );
}

function Sec({title,children}) {
  return (
    <div style={{background:"white",borderRadius:16,padding:16,marginBottom:12,boxShadow:"0 1px 6px rgba(0,0,0,.05)"}}>
      <div style={{fontSize:10,fontWeight:800,color:"#94a3b8",textTransform:"uppercase",letterSpacing:1.2,marginBottom:12}}>{title}</div>
      {children}
    </div>
  );
}
function IR({icon,label,val}) {
  return (
    <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
      <div style={{background:"#f1f5f9",borderRadius:8,padding:7,flexShrink:0}}><I n={icon} s={14} c="#64748b"/></div>
      <div><div style={{fontSize:10,color:"#94a3b8"}}>{label}</div><div style={{fontSize:14,fontWeight:600,color:"#1e293b"}}>{val}</div></div>
    </div>
  );
}
function MBox({label,v,hi,color,prefix="$",suffix=""}) {
  return (
    <div style={{background:hi?"#eff6ff":"#f8fafc",borderRadius:11,padding:12,border:hi?"1px solid #bfdbfe":"none"}}>
      <div style={{fontSize:10,color:"#94a3b8",marginBottom:2}}>{label}</div>
      <div style={{fontSize:16,fontWeight:900,color:color||(hi?"#2563eb":"#1e293b")}}>
        {prefix}{typeof v==="number"?v.toLocaleString("es-AR"):v}{suffix}
      </div>
    </div>
  );
}
function StatusChip({label,val}) {
  const ok=val==="Sí";
  return (
    <div>
      <div style={{fontSize:10,color:"#94a3b8",marginBottom:2}}>{label}</div>
      <div style={{fontSize:13,fontWeight:700,color:ok?"#15803d":"#ef4444"}}>{ok?"✓ "+val:"✗ "+val}</div>
    </div>
  );
}

// ─── EDIT FORM ────────────────────────────────────────────────────────────────
function EditForm({data,onChange}) {
  const F=(key,label,type="text",opts=null)=>(
    <div style={{marginBottom:13}}>
      <label style={S.lbl}>{label}</label>
      {opts?(
        <select style={S.inp} value={data[key]||""} onChange={e=>{
          const val=e.target.value;
          const extra=key==="area"?{precio:AREAS[val]?.precio||130000}:{};
          onChange({...data,[key]:val,...extra});
        }}>{opts.map(o=><option key={o} value={o}>{o}</option>)}</select>
      ):(
        <input style={S.inp} type={type} value={data[key]||""} onChange={e=>onChange({...data,[key]:type==="number"?Number(e.target.value):e.target.value})}/>
      )}
    </div>
  );
  return (
    <div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0 10px"}}>
        <div>{F("nombre","Nombre")}</div>
        <div>{F("apellido","Apellido")}</div>
      </div>
      {F("dni","DNI")}
      {F("celular","Celular","tel")}
      {F("email","Email","email")}
      {F("area","Área","text",Object.keys(AREAS))}
      {F("grupo","Grupo","text",data.area==="Ágora"?["Ágora"]:["1","2","3","4","5","6","7","8","9","10","11","12","13","14"])}
      {F("rol","Rol","text",["participante","coordinador"])}
      {F("estado","Estado","text",["No pagó","Parcial","Pagado","Debe efectivo"])}
      <div style={{background:"#f8fafc",borderRadius:12,padding:12,marginBottom:13}}>
        <div style={{fontSize:11,fontWeight:700,color:"#64748b",marginBottom:8}}>PRECIO RETIRO: {$ar(data.precio||130000)}</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0 10px"}}>
          <div>{F("pago_efectivo","Efectivo","number")}</div>
          <div>{F("pago_transferencia","Transferencia","number")}</div>
        </div>
      </div>
      {F("comprobante","Comprobante","text",["No","Sí"])}
      {F("autorizacion","Autorización","text",["No","Sí"])}
      {F("vendio_entradas","Vendió entradas","text",["No","Sí"])}
      {F("cantidad_entradas","Cant. entradas","number")}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0 10px"}}>
        <div>{F("entradas_efectivo","Entradas efvo","number")}</div>
        <div>{F("entradas_transferencia","Entradas transf","number")}</div>
      </div>
      {F("entro_plata","Entró plata","text",["No","Sí"])}
      <div style={{marginBottom:13}}>
        <label style={S.lbl}>Observaciones</label>
        <textarea style={{...S.inp,height:75,resize:"none"}} value={data.observaciones||""} onChange={e=>onChange({...data,observaciones:e.target.value})}/>
      </div>
    </div>
  );
}

// ─── PAGOS TAB ────────────────────────────────────────────────────────────────
function PagosTab({parts,stats}) {
  const [fArea,setFArea]=useState("all");
  const filtered=fArea==="all"?parts:parts.filter(p=>p.area===fArea);

  const byGrupo=useMemo(()=>{
    const g={};
    filtered.forEach(p=>{
      const key=p.area==="Ágora"?"Ágora":`Grupo ${p.grupo}`;
      if(!g[key])g[key]={total:0,count:0,pagados:0,parciales:0,noPago:0,precio:p.precio,area:p.area};
      g[key].total+=(p.pago_efectivo||0)+(p.pago_transferencia||0);
      g[key].count++;
      if(p.estado==="Pagado")g[key].pagados++;
      else if(p.estado==="Parcial")g[key].parciales++;
      else g[key].noPago++;
    });
    return Object.entries(g).sort((a,b)=>b[1].total-a[1].total);
  },[filtered]);

  const fRec=filtered.reduce((s,p)=>s+(p.pago_efectivo||0)+(p.pago_transferencia||0),0);
  const fDeuda=filtered.filter(p=>p.estado!=="Pagado").reduce((s,p)=>s+Math.max((p.precio||0)-((p.pago_efectivo||0)+(p.pago_transferencia||0)),0),0);

  return (
    <div style={{padding:"16px 16px 0"}}>
      {/* Area filter */}
      <div style={{display:"flex",gap:6,marginBottom:12,overflowX:"auto",paddingBottom:2}}>
        {["all",...Object.keys(AREAS)].map(a=>(
          <button key={a} onClick={()=>setFArea(a)} style={{flexShrink:0,padding:"5px 13px",borderRadius:20,border:"none",background:fArea===a?"#1e3a5f":"#f1f5f9",color:fArea===a?"white":"#64748b",fontSize:12,fontWeight:600,cursor:"pointer"}}>
            {a==="all"?"Todas":a}
          </button>
        ))}
      </div>

      {/* Summary */}
      <div style={{background:"linear-gradient(135deg,#14532d,#22c55e)",borderRadius:20,padding:20,marginBottom:12,color:"white"}}>
        <div style={{fontSize:12,opacity:.8}}>Recaudado {fArea==="all"?"total":fArea}</div>
        <div style={{fontSize:28,fontWeight:900,letterSpacing:-1}}>{$ar(fRec)}</div>
        <div style={{fontSize:12,opacity:.7,marginTop:8}}>Deuda pendiente: <span style={{color:"#fca5a5",fontWeight:700}}>{$ar(fDeuda)}</span></div>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14}}>
        <div style={{...S.card,borderLeft:"3px solid #22c55e"}}>
          <div style={{fontSize:11,color:"#94a3b8"}}>Pagados completos</div>
          <div style={{fontSize:22,fontWeight:900,color:"#15803d"}}>{filtered.filter(p=>p.estado==="Pagado").length}</div>
        </div>
        <div style={{...S.card,borderLeft:"3px solid #eab308"}}>
          <div style={{fontSize:11,color:"#94a3b8"}}>Con deuda</div>
          <div style={{fontSize:22,fontWeight:900,color:"#a16207"}}>{filtered.filter(p=>p.estado!=="Pagado").length}</div>
        </div>
      </div>

      {/* Por grupo/área */}
      <div style={{fontSize:12,fontWeight:800,color:"#94a3b8",marginBottom:8}}>POR GRUPO</div>
      <div style={{display:"flex",flexDirection:"column",gap:8,paddingBottom:8}}>
        {byGrupo.map(([nombre,d])=>{
          const areaCfg=AREAS[d.area]||AREAS["Caminar"];
          const pct=Math.round((d.pagados/Math.max(d.count,1))*100);
          return (
            <div key={nombre} style={{...S.card,border:`1px solid ${areaCfg.color}18`}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
                <div>
                  <div style={{fontSize:14,fontWeight:700,color:"#1e293b"}}>{nombre}</div>
                  <div style={{fontSize:11,color:"#64748b"}}>{d.count} personas · {d.pagados} pagados · precio {$ar(d.precio)}</div>
                </div>
                <div style={{fontSize:16,fontWeight:900,color:"#1e293b"}}>{$ar(d.total)}</div>
              </div>
              <div style={{background:"#f1f5f9",borderRadius:6,height:6,overflow:"hidden"}}>
                <div style={{background:areaCfg.color,height:"100%",width:`${pct}%`,borderRadius:6,transition:"width .4s"}}/>
              </div>
              <div style={{fontSize:11,color:"#64748b",marginTop:4}}>{pct}% pagado completo</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── ENTRADAS TAB ─────────────────────────────────────────────────────────────
function EntradasTab({parts}) {
  const vendedores=useMemo(()=>
    parts.filter(p=>p.cantidad_entradas>0)
      .map(p=>({nombre:`${p.nombre} ${p.apellido}`,grupo:p.grupo,area:p.area,cantidad:p.cantidad_entradas,total:(p.entradas_efectivo||0)+(p.entradas_transferencia||0)}))
      .sort((a,b)=>b.cantidad-a.cantidad)
  ,[parts]);
  const totEnt=vendedores.reduce((s,v)=>s+v.cantidad,0);
  const totDin=vendedores.reduce((s,v)=>s+v.total,0);
  const podio=vendedores.slice(0,3);
  const M=["🥇","🥈","🥉"];
  return (
    <div style={{padding:"16px 16px 0"}}>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14}}>
        <div style={{background:"linear-gradient(135deg,#4c1d95,#8b5cf6)",borderRadius:16,padding:16,color:"white"}}>
          <div style={{fontSize:11,opacity:.8}}>Total entradas</div>
          <div style={{fontSize:28,fontWeight:900}}>{totEnt}</div>
          <div style={{fontSize:11,opacity:.7}}>boletos</div>
        </div>
        <div style={{background:"linear-gradient(135deg,#be185d,#ec4899)",borderRadius:16,padding:16,color:"white"}}>
          <div style={{fontSize:11,opacity:.8}}>Recaudado</div>
          <div style={{fontSize:22,fontWeight:900}}>{$ar(totDin)}</div>
          <div style={{fontSize:11,opacity:.7}}>en entradas</div>
        </div>
      </div>

      {podio.length>0 && (
        <>
          <div style={{fontSize:12,fontWeight:800,color:"#94a3b8",marginBottom:8}}>🏆 RANKING VENDEDORES</div>
          <div style={{display:"flex",gap:8,marginBottom:14,alignItems:"flex-end"}}>
            {[podio[1],podio[0],podio[2]].map((v,i)=>v&&(
              <div key={i} style={{flex:i===1?1.4:1,background:"white",borderRadius:16,padding:14,textAlign:"center",boxShadow:"0 4px 16px rgba(0,0,0,.08)",border:i===1?"2px solid #fbbf24":"1px solid #f1f5f9"}}>
                <div style={{fontSize:i===1?32:24}}>{M[i===0?1:i===1?0:2]}</div>
                <div style={{fontSize:12,fontWeight:700,color:"#1e293b",marginTop:4,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{v.nombre.split(" ")[0]}</div>
                <div style={{fontSize:i===1?22:18,fontWeight:900,color:i===1?"#d97706":"#1e293b"}}>{v.cantidad}</div>
                <div style={{fontSize:10,color:"#94a3b8"}}>boletos</div>
                <div style={{fontSize:11,color:"#64748b",marginTop:2,fontWeight:600}}>{$ar(v.total)}</div>
              </div>
            ))}
          </div>
        </>
      )}

      <div style={{display:"flex",flexDirection:"column",gap:8,paddingBottom:8}}>
        {vendedores.map((v,i)=>{
          const areaCfg=AREAS[v.area]||AREAS["Caminar"];
          return (
            <div key={i} style={{...S.card,display:"flex",gap:12,alignItems:"center"}}>
              <div style={{width:28,height:28,borderRadius:"50%",background:i<3?"#fef3c7":"#f1f5f9",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:12,color:i<3?"#d97706":"#64748b",flexShrink:0}}>{i+1}</div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:14,fontWeight:700,color:"#1e293b",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{v.nombre}</div>
                <div style={{fontSize:11,color:"#64748b"}}>{areaCfg.emoji} {v.area} · G.{v.grupo}</div>
              </div>
              <div style={{textAlign:"right",flexShrink:0}}>
                <div style={{fontSize:16,fontWeight:800,color:"#8b5cf6"}}>{v.cantidad} <span style={{fontSize:10,fontWeight:500,color:"#94a3b8"}}>boletos</span></div>
                <div style={{fontSize:12,fontWeight:600,color:"#64748b"}}>{$ar(v.total)}</div>
              </div>
            </div>
          );
        })}
        {vendedores.length===0 && <div style={{textAlign:"center",color:"#94a3b8",padding:40}}>Sin vendedores registrados</div>}
      </div>
    </div>
  );
}

// ─── ASISTENCIA TAB ───────────────────────────────────────────────────────────
function AsisTab({parts,grupos14,onToggle,stats,showToast}) {
  const [q,setQ]=useState("");
  const [fGrupo,setFGrupo]=useState("all");
  const [fArea,setFArea]=useState("all");

  const filtered=parts.filter(p=>{
    const txt=q.toLowerCase();
    const mQ=!txt||`${p.nombre} ${p.apellido}`.toLowerCase().includes(txt);
    const mG=fGrupo==="all"||(p.area==="Ágora"&&fGrupo==="Ágora")||p.grupo===fGrupo;
    const mA=fArea==="all"||p.area===fArea;
    return mQ&&mG&&mA;
  });

  const presentes=filtered.filter(p=>p.asistencia).length;
  return (
    <div style={{padding:"16px 16px 0"}}>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:12}}>
        <div style={{background:"#dcfce7",borderRadius:12,padding:12,textAlign:"center"}}>
          <div style={{fontSize:22,fontWeight:900,color:"#15803d"}}>{stats.presentes}</div>
          <div style={{fontSize:10,color:"#166534",fontWeight:700}}>PRESENTES</div>
        </div>
        <div style={{background:"#fee2e2",borderRadius:12,padding:12,textAlign:"center"}}>
          <div style={{fontSize:22,fontWeight:900,color:"#dc2626"}}>{stats.total-stats.presentes}</div>
          <div style={{fontSize:10,color:"#991b1b",fontWeight:700}}>AUSENTES</div>
        </div>
        <div style={{background:"#eff6ff",borderRadius:12,padding:12,textAlign:"center"}}>
          <div style={{fontSize:22,fontWeight:900,color:"#2563eb"}}>{Math.round((stats.presentes/Math.max(stats.total,1))*100)}%</div>
          <div style={{fontSize:10,color:"#1d4ed8",fontWeight:700}}>ASISTENCIA</div>
        </div>
      </div>

      <div style={{position:"relative",marginBottom:8}}>
        <div style={{position:"absolute",left:11,top:"50%",transform:"translateY(-50%)"}}><I n="search" s={15} c="#94a3b8"/></div>
        <input style={{...S.inp,paddingLeft:34}} value={q} onChange={e=>setQ(e.target.value)} placeholder="Buscar..."/>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:12}}>
        <select style={{...S.inp,fontSize:12,padding:"9px 10px"}} value={fArea} onChange={e=>{setFArea(e.target.value);setFGrupo("all");}}>
          <option value="all">Todas las áreas</option>
          {Object.keys(AREAS).map(a=><option key={a}>{a}</option>)}
        </select>
        <select style={{...S.inp,fontSize:12,padding:"9px 10px"}} value={fGrupo} onChange={e=>setFGrupo(e.target.value)}>
          <option value="all">Todos grupos</option>
          {grupos14.map(g=><option key={g} value={g}>Grupo {g}</option>)}
          <option value="Ágora">Ágora</option>
        </select>
      </div>

      <div style={{fontSize:12,color:"#64748b",marginBottom:8,fontWeight:600}}>
        {presentes} presentes de {filtered.length} filtrados
      </div>

      <div style={{display:"flex",flexDirection:"column",gap:7,paddingBottom:8}}>
        {filtered.map(p=>{
          const areaCfg=AREAS[p.area]||AREAS["Caminar"];
          return (
            <div key={p.id} style={{background:"white",borderRadius:13,padding:"11px 13px",display:"flex",alignItems:"center",gap:12,boxShadow:"0 1px 6px rgba(0,0,0,.05)",border:p.asistencia?`1px solid ${areaCfg.color}40`:"1px solid #f1f5f9"}}>
              <button onClick={()=>onToggle(p.id)} style={{width:26,height:26,borderRadius:"50%",border:"none",background:p.asistencia?areaCfg.color:"#e2e8f0",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,transition:"background .2s"}}>
                {p.asistencia&&<I n="check" s={13} c="white"/>}
              </button>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:14,fontWeight:700,color:"#1e293b",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
                  {p.nombre} {p.apellido}
                  {p.rol==="coordinador"&&<span style={{marginLeft:6,fontSize:9,background:"#fef3c7",color:"#d97706",padding:"1px 5px",borderRadius:10,fontWeight:800}}>COORD</span>}
                </div>
                <div style={{fontSize:11,color:"#64748b"}}>{areaCfg.emoji} {p.area} · G.{p.grupo}</div>
              </div>
              <span style={{fontSize:11,fontWeight:600,color:p.asistencia?areaCfg.color:"#94a3b8",flexShrink:0}}>
                {p.asistencia?"Presente":"Ausente"}
              </span>
            </div>
          );
        })}
      </div>

      <button style={{...S.btn,width:"100%",justifyContent:"center",marginBottom:20,padding:14}} onClick={()=>showToast("Asistencia guardada ✓")}>
        <I n="save" s={16} c="white"/> Guardar asistencia
      </button>
    </div>
  );
}

// ─── MÁS TAB ─────────────────────────────────────────────────────────────────
function MasTab({user,stats,onLogout}) {
  const resumen=[
    {label:"Caminar",icon:"walk",sub:"14 grupos · $130.000",c:"#2563eb"},
    {label:"Ágora",icon:"agora",sub:"1 grupo · $40.000",c:"#ec4899"},
    {label:"Confirmación",icon:"star",sub:"$130.000 (próximamente)",c:"#8b5cf6"},
    {label:"Preconfirmación",icon:"star",sub:"$130.000 (próximamente)",c:"#f59e0b"},
  ];
  return (
    <div style={{padding:"16px 16px 0"}}>
      <div style={{background:"linear-gradient(160deg,#0f172a,#1e3a5f)",borderRadius:20,padding:20,marginBottom:16,color:"white",textAlign:"center"}}>
        <div style={{fontSize:44,marginBottom:6}}>✝️</div>
        <div style={{fontSize:20,fontWeight:900}}>RetiroApp</div>
        <div style={{fontSize:12,opacity:.7,marginTop:2}}>v2.0 · 286 participantes · 4 áreas</div>
        <div style={{marginTop:14,background:"rgba(255,255,255,.12)",borderRadius:12,padding:12,textAlign:"left"}}>
          <div style={{fontSize:12,fontWeight:700}}>{user.name}</div>
          <div style={{fontSize:11,opacity:.7}}>Rol: {user.role}</div>
        </div>
      </div>

      {/* Áreas config */}
      <div style={{fontSize:12,fontWeight:800,color:"#94a3b8",marginBottom:8}}>CONFIGURACIÓN DE ÁREAS</div>
      <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:14}}>
        {resumen.map(r=>(
          <div key={r.label} style={{...S.card,display:"flex",gap:12,alignItems:"center",borderLeft:`3px solid ${r.c}`}}>
            <div style={{background:r.c+"18",borderRadius:10,padding:10}}><I n={r.icon} s={18} c={r.c}/></div>
            <div>
              <div style={{fontSize:14,fontWeight:700,color:"#1e293b"}}>{r.label}</div>
              <div style={{fontSize:12,color:"#64748b"}}>{r.sub}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Actions */}
      <div style={{fontSize:12,fontWeight:800,color:"#94a3b8",marginBottom:8}}>HERRAMIENTAS</div>
      <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:14}}>
        {[
          {i:"group",l:"Ver por grupos",d:"Caminar G1–G14 + coordinadores"},
          {i:"up",l:"Importar Excel",d:"Actualizar datos desde planilla"},
          {i:"down",l:"Exportar Excel",d:"Descargar datos completos"},
          {i:"down",l:"Exportar CSV",d:"Para Google Sheets / análisis"},
          {i:"alert",l:"Deudores",d:`${stats.noPago+stats.debe} pendientes · ${$ar(stats.deuda)}`},
          {i:"trophy",l:"Estadísticas",d:"Reportes y análisis completo"},
        ].map(x=>(
          <div key={x.l} onClick={()=>alert(`${x.l}: próximamente`)} style={{...S.card,display:"flex",gap:12,alignItems:"center",cursor:"pointer"}}>
            <div style={{background:"#f1f5f9",borderRadius:10,padding:10,flexShrink:0}}><I n={x.i} s={17} c="#1e3a5f"/></div>
            <div style={{flex:1}}>
              <div style={{fontSize:14,fontWeight:700,color:"#1e293b"}}>{x.l}</div>
              <div style={{fontSize:12,color:"#64748b"}}>{x.d}</div>
            </div>
          </div>
        ))}
      </div>

      <button onClick={onLogout} style={{...S.btn,width:"100%",justifyContent:"center",background:"#fee2e2",color:"#dc2626",marginBottom:20,padding:13}}>
        <I n="logout" s={16} c="#dc2626"/> Cerrar sesión
      </button>
    </div>
  );
}

// ─── BOTTOM NAV ───────────────────────────────────────────────────────────────
function BottomNav({tab,setTab}) {
  const items=[
    {id:"home",i:"home",l:"Inicio"},
    {id:"partic",i:"users",l:"Personas"},
    {id:"pagos",i:"dollar",l:"Pagos"},
    {id:"entradas",i:"ticket",l:"Entradas"},
    {id:"asistencia",i:"check",l:"Asistencia"},
    {id:"mas",i:"more",l:"Más"},
  ];
  return (
    <div style={{position:"fixed",bottom:0,left:0,right:0,background:"white",borderTop:"1px solid #e2e8f0",display:"flex",boxShadow:"0 -4px 20px rgba(0,0,0,.08)",zIndex:50,maxWidth:430,margin:"0 auto"}}>
      {items.map(x=>(
        <button key={x.id} onClick={()=>setTab(x.id)} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:2,padding:"10px 4px 8px",background:"none",border:"none",cursor:"pointer",WebkitTapHighlightColor:"transparent"}}>
          <I n={x.i} s={20} c={tab===x.id?"#1e3a5f":"#cbd5e1"}/>
          <span style={{fontSize:9,fontWeight:tab===x.id?800:500,color:tab===x.id?"#1e3a5f":"#94a3b8"}}>{x.l}</span>
          {tab===x.id && <div style={{width:4,height:4,borderRadius:"50%",background:"#1e3a5f"}}/>}
        </button>
      ))}
    </div>
  );
}
